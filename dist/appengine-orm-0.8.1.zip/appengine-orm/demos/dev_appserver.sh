#!/bin/bash
# Launches the development AppServer
SDK_BIN=`dirname $0`
SDK_LIB=$SDK_BIN/../lib
java -cp $SDK_LIB/appengine-tools-api.jar \
  com.google.appengine.tools.development.DevAppServerMain $*
